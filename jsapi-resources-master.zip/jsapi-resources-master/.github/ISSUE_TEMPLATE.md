<!--

Generic requests for assistance with the [ArcGIS API for Javascript](http://js.arcgis.com) are better off made through the following avenues.

* Esri Tech Support - https://support.esri.com/contact-tech-support
* the Esri community on GeoNet - https://geonet.esri.com/community/developers/web-developers/arcgis-api-for-javascript

We welcome feedback and questions related to the TypeScript definitions and other files in this repository here.

-->

I am reporting an issue with 

- [ ] TypeScript definitions
- [ ] another resource in this repository
