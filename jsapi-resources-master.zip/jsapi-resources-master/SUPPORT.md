If you need support for the [ArcGIS API for JavaScript](https://developers.arcgis.com/javascript/),  there are several 
ways you can ask for assistance or provide feedback on the [ArcGIS API for JavaScript](http://js.arcgis.com) from 
[Esri](https://www.esri.com/).

* Contact [Esri Support](https://support.esri.com/contact-tech-support) - if you're a current Esri customer
* Ask the Esri community on [GeoNet](https://geonet.esri.com/community/developers/web-developers/arcgis-api-for-javascript)
