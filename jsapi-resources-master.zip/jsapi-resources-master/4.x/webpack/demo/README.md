# Sample using @arcgis/webpack-plugin

## Usage

```
npm install

# run local dev server
npm start

# create a production build
npm run build
```