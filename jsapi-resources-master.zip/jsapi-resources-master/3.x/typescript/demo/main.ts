import MapController = require("./MapController");

var mapController = new MapController("mapDiv");
mapController.start();
